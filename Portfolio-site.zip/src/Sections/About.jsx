import person from "../assets/me111.png";
import '../css/About.css'
const About = ()=>{

    return(
        <>
        <section className="about">
            <div className="about-image">
                <img src ={person} alt="Aayush Pandey"/>
            </div>
            <div className="about-content">
                <h2>Give me ideas & I’ll turn them into intelligent, <br></br>
                AI-powered systems that Rock</h2>
                <p> I love building full-stack systems from the ground up —
                    architecting scalable backends, crafting seamless frontends,
                    and weaving in ML to keep products sharp in a world that never
                    stops moving.<br></br>
                    For me, engineering is crafting what you want into reality.
                    I bring both depth and passion to every layer, because I
                    believe the best products are made by people who truly love
                    what they build.</p>
                    </div>
        </section>
        </>
    )
}

export default About;