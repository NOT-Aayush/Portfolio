import { useEffect, useRef } from "react";
import { FaGithub, FaLinkedin, FaInstagram, FaEnvelope } from "react-icons/fa";
import "../css/Contact.css";

const LINKS = [
  {
    href:  "mailto:aayush4373pandey@gmail.com",
    icon:  <FaEnvelope />,
    label: "Email",
    external: false,
  },
  {
    href:  "https://linkedin.com/in/aayush-pandey",
    icon:  <FaLinkedin />,
    label: "LinkedIn",
    external: true,
  },
  {
    href:  "https://github.com/NOT-Aayush",
    icon:  <FaGithub />,
    label: "GitHub",
    external: true,
  },
  {
    href:  "https://instagram.com",
    icon:  <FaInstagram />,
    label: "Instagram",
    external: true,
  },
];

const Contact = () => {
  const titleRef  = useRef(null);
  const bodyRef   = useRef(null);

  useEffect(() => {
    const init = () => {
      if (!window.gsap || !window.ScrollTrigger) return;
      const { gsap, ScrollTrigger } = window;
      gsap.registerPlugin(ScrollTrigger);

      gsap.to(titleRef.current, {
        opacity: 1, y: 0, duration: .8, ease: "power3.out",
        scrollTrigger: { trigger: titleRef.current, start: "top 85%" },
      });

      gsap.to(bodyRef.current, {
        opacity: 1, y: 0, duration: .9, ease: "power3.out",
        scrollTrigger: { trigger: bodyRef.current, start: "top 85%" },
      });
    };

    const timer = setTimeout(init, 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="contact" id="contact">
      <h1 className="contact-title" ref={titleRef}>Contact</h1>

      <div className="contact-container" ref={bodyRef}>
        <div className="contact-left">
          <h2>Let's level up your work</h2>
          <p>
            Have a project in mind? Looking for a partner who cares
            about your product as much as you do? Drop me a line.
          </p>
          <a
            href="/data/Aayu_resume.pdf"
            target="_blank"
            rel="noreferrer"
            className="resume-btn"
          >
            ↓ Resume
          </a>
        </div>

        <div className="contact-right">
          {LINKS.map(({ href, icon, label, external }) => (
            <a
              key={label}
              href={href}
              className="contact-item"
              target={external ? "_blank" : undefined}
              rel={external ? "noreferrer" : undefined}
            >
              <div className="icon-circle">{icon}</div>
              <span>{label}</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Contact;
