import { useState, useEffect, useRef } from "react";
import { internships }  from "../data/internships";
import { certificates } from "../data/certificates";
import "../css/Experience.css";

const Experience = () => {
  const [tab, setTab] = useState("internships");
  const titleRef = useRef(null);
  const tabsRef  = useRef(null);
  const listRef  = useRef(null);

  const items = tab === "internships" ? internships : certificates;

  // Animate cards in when tab changes
  useEffect(() => {
    if (!window.gsap) return;
    const cards = listRef.current?.querySelectorAll(".experience-card");
    if (!cards) return;

    window.gsap.fromTo(
      cards,
      { opacity: 0, x: -30 },
      { opacity: 1, x: 0, duration: .5, stagger: .12, ease: "power3.out" }
    );
  }, [tab]);

  // Initial scroll trigger
  useEffect(() => {
    const init = () => {
      if (!window.gsap || !window.ScrollTrigger) return;
      const { gsap, ScrollTrigger } = window;
      gsap.registerPlugin(ScrollTrigger);

      gsap.to(titleRef.current, {
        opacity: 1, y: 0, duration: .8, ease: "power3.out",
        scrollTrigger: { trigger: titleRef.current, start: "top 85%" },
      });

      gsap.to(tabsRef.current, {
        opacity: 1, duration: .6, ease: "power2.out",
        scrollTrigger: { trigger: tabsRef.current, start: "top 85%" },
      });
    };

    const timer = setTimeout(init, 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="experience" id="experience">
      <h1 className="experience-title" ref={titleRef}>Experience</h1>

      <div className="experience-tabs" ref={tabsRef}>
        <button
          className={tab === "internships" ? "active" : ""}
          onClick={() => setTab("internships")}
        >
          Internships
        </button>
        <button
          className={tab === "certificates" ? "active" : ""}
          onClick={() => setTab("certificates")}
        >
          Certificates
        </button>
      </div>

      <div className="experience-list" ref={listRef}>
        {items.map((item, index) => (
          <div className="experience-card" key={index}>
            <div className="experience-left">
              <h3>{item.title}</h3>
              {item.period  && <span>{item.period}</span>}
              {item.issuer  && <span>{item.issuer}</span>}
            </div>

            <div className="experience-divider" />

            <div className="experience-right">
              <p>{item.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Experience;
