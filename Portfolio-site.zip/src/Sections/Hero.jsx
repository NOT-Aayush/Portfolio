import "../css/Hero.css";
import person from "../assets/me111.png";

const Hero = () => {
  return (
    <section className="hero">
      <div className="hero-image">
        <img src={person} alt="Aayush Pandey" />
      </div>
      <h2 className="hero-greet">Hi!</h2>      
      <p className="hero-desc">I am</p>
      <h2 className="hero-name">Aayush Pandey</h2>

      <h1 className="hero-title">AI & Full Stack Developer</h1>
    </section>
  );
};

export default Hero;