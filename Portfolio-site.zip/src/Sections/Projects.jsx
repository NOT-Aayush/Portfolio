import { useState, useEffect, useRef } from "react";
import { projects } from "../data/projects";
import "../css/Projects.css";

const Projects = () => {
  const [current, setCurrent] = useState(0);
  const headingRef  = useRef(null);
  const carouselRef = useRef(null);

  const prev = (current - 1 + projects.length) % projects.length;
  const next = (current + 1) % projects.length;

  // Keyboard navigation
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "ArrowLeft")  setCurrent(prev);
      if (e.key === "ArrowRight") setCurrent(next);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [prev, next]);

  // GSAP scroll reveal
  useEffect(() => {
    const init = () => {
      if (!window.gsap || !window.ScrollTrigger) return;
      const { gsap, ScrollTrigger } = window;
      gsap.registerPlugin(ScrollTrigger);

      gsap.to(headingRef.current, {
        opacity: 1, y: 0, duration: .8, ease: "power3.out",
        scrollTrigger: { trigger: headingRef.current, start: "top 85%" },
      });

      gsap.to(carouselRef.current, {
        opacity: 1, duration: 1, ease: "power2.out",
        scrollTrigger: { trigger: carouselRef.current, start: "top 80%" },
      });
    };

    const timer = setTimeout(init, 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="projects" id="projects">
      <h1 className="projects-heading" ref={headingRef}>
        MY PROJECTS
      </h1>

      <div className="carousel-container" ref={carouselRef}>
        <button
          className="carousel-btn left"
          onClick={() => setCurrent(prev)}
          aria-label="Previous project"
        >
          ❮
        </button>

        <div className="carousel">
          {projects.map((project, index) => {
            let className = "project-card hidden-card";
            if (index === current) className = "project-card center-card";
            else if (index === prev) className = "project-card left-card";
            else if (index === next) className = "project-card right-card";

            return (
              <div
                key={index}
                className={className}
                onClick={() => setCurrent(index)}
              >
                {project.image ? (
                  <img src={project.image} alt={project.title} />
                ) : (
                  <div className="project-card-placeholder">
                    {project.icon || "💡"}
                  </div>
                )}

                <div className="project-overlay">
                  <h2>{project.title}</h2>

                  {index === current && (
                    <div className="project-details">
                      <p>{project.description}</p>
                      <span>{project.tech}</span>

                      <div className="project-links">
                        <a
                          href={project.github}
                          target="_blank"
                          rel="noreferrer"
                          onClick={e => e.stopPropagation()}
                        >
                          GitHub
                        </a>
                        <a
                          href={project.live}
                          target="_blank"
                          rel="noreferrer"
                          onClick={e => e.stopPropagation()}
                        >
                          Live Demo
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <button
          className="carousel-btn right"
          onClick={() => setCurrent(next)}
          aria-label="Next project"
        >
          ❯
        </button>
      </div>

      {/* Dot indicators */}
      <div style={{ display: "flex", gap: ".5rem", marginTop: "2rem", position: "relative", zIndex: 1 }}>
        {projects.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            aria-label={`Go to project ${i + 1}`}
            style={{
              width: i === current ? "24px" : "8px",
              height: "8px",
              borderRadius: "4px",
              background: i === current ? "var(--clr-red)" : "rgba(255,255,255,.25)",
              border: "none",
              cursor: "pointer",
              transition: "all .3s ease",
              padding: 0,
            }}
          />
        ))}
      </div>
    </section>
  );
};

export default Projects;
