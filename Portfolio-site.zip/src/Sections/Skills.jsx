import { useState, useEffect, useRef } from "react";
import { skills } from "../data/skills";
import "../css/Skills.css";

// Icon map for each skill item — falls back to a dot if not found
const ICONS = {
  // Languages
  Python: "🐍", Java: "☕", JavaScript: "⚡", TypeScript: "🔷", "C++": "⚙️",
  // Frontend
  React: "⚛️", Vite: "🔥", Tailwind: "🌊", HTML: "📄", CSS: "🎨",
  // Backend
  "Node.js": "🟢", Express: "🚂", Electron: "💠", Prisma: "▲",
  // Databases
  PostgreSQL: "🐘", MongoDB: "🍃", MySQL: "🐬", SQLite: "📦",
  // AI/ML
  TensorFlow: "🤖", OpenCV: "👁️", NumPy: "🔢", Keras: "🧠",
  // Tools
  Docker: "🐳", AWS: "☁️", GitHub: "🐙", Linux: "🐧", Vercel: "▲",
};

// Accent colour per category for the active tab underline / card glow
const ACCENT = {
  "Languages":  "#4f8ef7",
  "Frontend":   "#a78bfa",
  "Backend":    "#34d399",
  "Databases":  "#f59e0b",
  "AI / ML":    "#f87171",
  "Tools":      "#38bdf8",
};

const Skills = () => {
  const [activeTab, setActiveTab]     = useState(0);
  const [prevTab, setPrevTab]         = useState(null);
  const [animDir, setAnimDir]         = useState("right"); // slide direction

  const titleRef  = useRef(null);
  const tabsRef   = useRef(null);
  const gridRef   = useRef(null);

  // Switch tab with direction awareness
  const switchTab = (idx) => {
    if (idx === activeTab) return;
    setAnimDir(idx > activeTab ? "right" : "left");
    setPrevTab(activeTab);
    setActiveTab(idx);
  };

  // Stagger grid cards when tab changes
  useEffect(() => {
    if (!window.gsap || !gridRef.current) return;
    const cards = gridRef.current.querySelectorAll(".skill-item");
    window.gsap.fromTo(
      cards,
      {
        opacity: 0,
        y: 24,
        scale: 0.92,
      },
      {
        opacity: 1,
        y: 0,
        scale: 1,
        duration: .45,
        stagger: .055,
        ease: "back.out(1.4)",
      }
    );
  }, [activeTab]);

  // Section scroll reveal
  useEffect(() => {
    const init = () => {
      if (!window.gsap || !window.ScrollTrigger) return;
      const { gsap, ScrollTrigger } = window;
      gsap.registerPlugin(ScrollTrigger);

      gsap.fromTo(
        titleRef.current,
        { opacity: 0, y: -24 },
        {
          opacity: 1, y: 0, duration: .8, ease: "power3.out",
          scrollTrigger: { trigger: titleRef.current, start: "top 85%" },
        }
      );

      gsap.fromTo(
        tabsRef.current,
        { opacity: 0, y: 16 },
        {
          opacity: 1, y: 0, duration: .7, ease: "power3.out",
          scrollTrigger: { trigger: tabsRef.current, start: "top 85%" },
        }
      );
    };

    const timer = setTimeout(init, 300);
    return () => clearTimeout(timer);
  }, []);

  const current = skills[activeTab];
  const accent  = ACCENT[current.category] || "var(--clr-red)";

  return (
    <section className="skills" id="skills">
      <h1 className="skills-title" ref={titleRef}>SKILLS</h1>

      {/* Category tabs */}
      <div className="skills-tabs" ref={tabsRef}>
        {skills.map((s, i) => (
          <button
            key={s.category}
            className={`skills-tab${i === activeTab ? " active" : ""}`}
            style={{ "--tab-accent": ACCENT[s.category] }}
            onClick={() => switchTab(i)}
          >
            {s.category}
          </button>
        ))}
      </div>

      {/* Skill grid */}
      <div
        className="skills-grid"
        ref={gridRef}
        style={{ "--accent": accent }}
      >
        {current.items.map((item) => (
          <div className="skill-item" key={item}>
            <span className="skill-icon">{ICONS[item] || "◆"}</span>
            <span className="skill-name">{item}</span>
          </div>
        ))}
      </div>

      {/* Category description bar */}
      <div className="skills-meta" style={{ "--accent": accent }}>
        <span className="skills-meta-label">{current.category}</span>
        <span className="skills-meta-count">
          {current.items.length} technologies
        </span>
      </div>
    </section>
  );
};

export default Skills;
