export const projects = [
  {
    title: "MindConnect",
    image: null,
    icon: "🧠",
    description:
      "Mental health web app connecting users with therapists and peers. Real-time support, AI mood tracking, and expert matching.",
    tech: "React • Node.js • PostgreSQL • Socket.io",
    github: "#",
    live: "#",
  },
  {
    title: "MediScan",
    image: null,
    icon: "🩺",
    description:
      "Medical imaging software using OpenCV and ML for early anomaly detection. Supports X-ray, MRI, and CT scans.",
    tech: "Python • OpenCV • TensorFlow • Electron",
    github: "#",
    live: "#",
  },
  {
    title: "SpeakWithSigns",
    image: "../images/sws.jpeg",
    icon: "🤟",
    description:
      "Real-time sign language translator using MediaPipe and a custom gesture model. Bridges communication gaps instantly.",
    tech: "React • TensorFlow.js • MediaPipe • Express",
    github: "#",
    live: "#",
  },
  {
    title: "Investigation AI",
    image: "../images/Osint.jpeg",
    icon: "🔍",
    description:
      "AI-powered OSINT workspace for intelligence gathering and evidence analysis, built during DRDO internship.",
    tech: "React • Express • PostgreSQL • LangChain",
    github: "#",
    live: "#",
  },
];
